from django.urls import path
from . import views


urlpatterns = [
    path('', views.welcome),
    path('welcome/', views.welcome),
    path('logout/',views.user_logout),
    path('<page>/',views.action),
    path('<page>/<operation>/<int:id>/', views.action),
]